local M = {}

function M.calcSpread(api, ammoCnt, basicInaccuracy)
    local angle = 0.5 - ammoCnt / 20
    return {angle * 15, 0}
end

function M.shoot(api)
    local shoot_delay = api:getScriptParams().shoot_delay * 1000
    api:safeAsyncTask(function ()
        api:shootOnce(false)
        return false
    end,shoot_delay,0,1)
end

return M